import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

const ROOMS_TABLE = 'Rooms';

export const handler = async (event) => {
  const { room_number, room_type, price, features } = JSON.parse(event.body);

  try {
    let scanParams = {
      TableName: ROOMS_TABLE,
      FilterExpression: "room_number = :room_number",
      ExpressionAttributeValues: {
        ":room_number": room_number
      }
    };
    
    const existingRooms = await dynamodb.send(new ScanCommand(scanParams));
    
    if (existingRooms.Count > 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Room number already exists' }),
      };
    }

    scanParams = {
      TableName: ROOMS_TABLE,
      ProjectionExpression: "room_id"
    };
    
    const data = await dynamodb.send(new ScanCommand(scanParams));
    const maxRoomId = data.Items.reduce((max, item) => Math.max(max, parseInt(item.room_id)), 0);
    
    const newRoomId = (maxRoomId + 1).toString();

    const params = {
      TableName: ROOMS_TABLE,
      Item: {
        room_id: newRoomId,
        room_number,
        room_type,
        price,
        features
      }
    };

    await dynamodb.send(new PutCommand(params));
    
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Room added successfully', room_id: newRoomId }),
    };
  }
  catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to add room', error: error.message }),
    };
  }
};
